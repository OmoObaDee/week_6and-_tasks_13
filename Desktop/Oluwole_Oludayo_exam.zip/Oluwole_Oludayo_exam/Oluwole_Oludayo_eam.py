# Question 1   Write a Python program that works as a basic calculator with continuous use.
def sum( d, p):
    return d+p

def substract(d, a):
    return d-a

def multiplication(d, z):
    return d *z

def division(p, g):
    if p != 0:
        return p/g
    return" your have performed invalid process check and complete the tasks"

while True:
    try:
        Number_1 = int(input( " Kindly enter your first number '1' choice please:"))
        Number_2 = int(input(" Your number two'2' choice of your"))

        prefered_Choices = input(" Select any operation to carry out please :(+, -,*, /) or  'quit to 'exit' the program please")

        print("<><"*30)
        if prefered_Choices == '+':
            print(sum( Number_1, Number_2))
        elif prefered_Choices == '-':
            print(substract(Number_1, Number_2))
        elif prefered_Choices =='*':
            print(multiplication(Number_1, Number_2))
        elif prefered_Choices =='/':
            print(division(Number_1, Number_2))
        elif prefered_Choices =='exit':
            print(" Thank you for your time")
    except ValueError as ve:
        print("Only valid Number and function are required..!!!")


# Question 2
# Question 2
# Complete the missing parts of the program below so that it keeps asking the user for a number and tells whether it is even or odd.
# Instruction

# Use input, int conversion, if-else control flow, and print output.
# Use a while loop that runs until the user types 'exit'.

while True:
    user_input = input("Enter a number (or type 'exit' to quit): ")
    if user_input == "exit" :
        print("Goodbye!")
        break        # break out of loop
    
    num = int(user_input)   # convert to integer
    
    if num % 2 == 0:
        print("The number is {user_input}. even number")
    else:
        print("The number is old {user_input}")
        print(" Thank you")




# Question 3
# The following code is supposed to ask for a user’s age repeatedly and say whether they are allowed to vote (18+).
# It should also exit if the user types 'exit'. However, the code contains errors.


while True:
    age = input("Enter your age (or type exit to quit): ")
    if age == exit:
        print("Goodbye!")
        break
    
    try:
        if age >= 18:
            print("You can vote")
        else:
            print("You cannot vote")
    except:
        print("Invalid input")

while True:
    age = input("Kindly provide your real  age  please !(or type'exit' to quit): ")  # Taking input from the voters.

# Validating the voter's age is it is less than 18n years of age
    if age.lower() == "exit":   # check for 'exit'
        print(" Your are not eligible to Vote!")
        print(" Come back when you are 18 years and Above please.")
        break

    try:
        age = int(age)  # convert to integer
        if age >= 18:  #  Complete the task of validating 
            print("Congratulation You can vote")
        else:
            print(" Sorry You cannot vote this year please")
    except:
        print(" Wrong input, please Kindly 'exit' Voting platform")
